import { useEffect, useState } from "react";
import TradeCalculator from "./components/TradeCalculator";
import ValueList from "./components/ValueList";
import MasteryCalculator from "./components/MasteryCalculator";
import StockTracker from "./components/StockTracker";
import TierList from "./components/TierList";
import FAQSection from "./components/FAQSection";
import ScamWarnings from "./components/ScamWarnings";
import SeoSections from "./components/SeoSections";
import { FRUITS } from "./data/fruits";

const SECTIONS = [
  { id: "calculator", label: "Trade Calculator", emoji: "⚖️" },
  { id: "values", label: "Value List", emoji: "📊" },
  { id: "mastery", label: "Mastery Calculator", emoji: "🎯" },
  { id: "stock", label: "Stock Tracker", emoji: "⏰" },
  { id: "tiers", label: "Tier List", emoji: "🏆" },
  { id: "scams", label: "Scam Warnings", emoji: "⚠️" },
  { id: "how-to", label: "How to Use", emoji: "📘" },
  { id: "top-values", label: "Top Values", emoji: "💎" },
  { id: "tools", label: "All Tools", emoji: "🧰" },
  { id: "faq", label: "FAQ", emoji: "❓" },
];

export default function App() {
  const [activeSection, setActiveSection] = useState("calculator");

  // Track which section is in view for the sticky nav.
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const inView = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (inView) setActiveSection(inView.target.id);
      },
      { rootMargin: "-30% 0px -55% 0px", threshold: [0, 0.5, 1] }
    );

    SECTIONS.forEach((s) => {
      const el = document.getElementById(s.id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 antialiased" style={{
      backgroundImage: "radial-gradient(at 20% 0%, rgba(124, 58, 237, 0.18) 0px, transparent 50%), radial-gradient(at 80% 100%, rgba(14, 165, 233, 0.18) 0px, transparent 50%)",
    }}>
      {/* Skip link for accessibility & SEO */}
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-3 focus:top-3 focus:z-50 focus:rounded focus:bg-violet-600 focus:px-3 focus:py-2 focus:text-white">
        Skip to main content
      </a>

      {/* HEADER with prominent trust badges */}
      <header className="sticky top-0 z-40 border-b border-white/10 bg-slate-950/85 backdrop-blur-lg">
        <div className="border-b border-white/5 bg-slate-900/60">
          <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-center gap-x-4 gap-y-1 px-4 py-2 text-[11px] font-bold sm:justify-between">
            <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/30 bg-emerald-500/15 px-2.5 py-1 text-emerald-200">
                <span aria-hidden="true">✓</span> No Signup
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/30 bg-emerald-500/15 px-2.5 py-1 text-emerald-200">
                <span aria-hidden="true">✓</span> No Credit Card
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-sky-400/30 bg-sky-500/15 px-2.5 py-1 text-sky-200">
                <span aria-hidden="true">🔓</span> 100% Free
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-violet-400/30 bg-violet-500/15 px-2.5 py-1 text-violet-200">
                <span aria-hidden="true">🎮</span> No Roblox Login
              </span>
            </div>
            <p className="hidden text-[11px] text-slate-300 sm:block">Updated for Blox Fruits Update 31 · 2026</p>
          </div>
        </div>
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500 via-fuchsia-500 to-indigo-600 shadow-lg shadow-fuchsia-500/30">
              <span className="text-lg" aria-hidden="true">🍇</span>
            </div>
            <div>
              <p className="text-sm font-bold leading-tight text-white sm:text-base">BloxFruitsCalculator</p>
              <p className="text-[10px] font-medium uppercase tracking-wider text-slate-400">Free Trade Values & WFL Tool</p>
            </div>
          </div>
          <nav className="hidden gap-1 md:flex" aria-label="Page sections">
            {SECTIONS.slice(0, 5).map((s) => (
              <button
                key={s.id}
                onClick={() => scrollTo(s.id)}
                className={`rounded-md px-2.5 py-1.5 text-xs font-semibold transition ${activeSection === s.id ? "bg-violet-600 text-white" : "text-slate-300 hover:bg-slate-800"}`}
              >
                <span aria-hidden="true" className="mr-1">{s.emoji}</span>
                {s.label}
              </button>
            ))}
          </nav>
        </div>
        {/* Section nav (mobile/horizontal scroll) */}
        <div className="md:hidden">
          <div className="flex gap-1 overflow-x-auto px-4 pb-2 text-xs">
            {SECTIONS.map((s) => (
              <button
                key={s.id}
                onClick={() => scrollTo(s.id)}
                aria-pressed={activeSection === s.id}
                className={`flex-shrink-0 rounded-md px-2.5 py-1.5 font-semibold transition ${activeSection === s.id ? "bg-violet-600 text-white" : "bg-slate-800/60 text-slate-300"}`}
              >
                <span aria-hidden="true" className="mr-1">{s.emoji}</span>
                {s.label}
              </button>
            ))}
          </div>
        </div>
      </header>

      <main id="main" className="mx-auto max-w-6xl px-3 py-6 sm:px-6 sm:py-10">
        {/* Hero */}
        <section className="mb-6 text-center sm:mb-10">
          <h1 className="bg-gradient-to-r from-violet-300 via-fuchsia-300 to-sky-300 bg-clip-text text-3xl font-black leading-tight text-transparent sm:text-5xl">
            Blox Fruits Calculator
          </h1>
          <p className="mx-auto mt-3 max-w-3xl text-sm leading-relaxed text-slate-300 sm:text-lg">
            The #1 free <strong>Blox Fruits Trade Calculator</strong>. Check fruit values, get an instant W/F/L verdict,
            and avoid trade scams. <strong>No signup, no credit card</strong>, no Roblox login — just the most accurate
            calculator for {FRUITS.length}+ fruits in Roblox Blox Fruits.
          </p>
          <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-[11px] font-bold uppercase tracking-wider text-slate-300">
            <span className="rounded-md border border-white/10 bg-slate-800/60 px-2 py-1">{FRUITS.length} Fruits Tracked</span>
            <span className="rounded-md border border-white/10 bg-slate-800/60 px-2 py-1">6 Tools in One Page</span>
            <span className="rounded-md border border-white/10 bg-slate-800/60 px-2 py-1">Daily Value Refresh</span>
            <span className="rounded-md border border-white/10 bg-slate-800/60 px-2 py-1">Mobile Friendly</span>
          </div>
        </section>

        {/* Trade calculator */}
        <div id="calculator" className="mb-8">
          <TradeCalculator />
        </div>

        {/* Tools grid */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div id="mastery" className="lg:col-span-2 scroll-mt-32">
            <MasteryCalculator />
          </div>
          <div id="stock" className="lg:col-span-1 scroll-mt-32">
            <StockTracker />
          </div>
        </div>

        <div id="values" className="my-8 scroll-mt-32">
          <ValueList />
        </div>

        <div id="tiers" className="my-8 scroll-mt-32">
          <TierList />
        </div>

        <div id="top-values" className="my-8 scroll-mt-32">
          <SeoSections />
        </div>

        <div id="scams" className="my-8 scroll-mt-32">
          <ScamWarnings />
        </div>

        <div id="faq" className="my-8 scroll-mt-32">
          <FAQSection />
        </div>
      </main>

      <footer className="border-t border-white/10 bg-slate-950/80">
        <div className="mx-auto max-w-6xl px-4 py-8 text-center text-xs text-slate-400">
          <p>
            <strong className="text-slate-200">BloxFruitsCalculator</strong> is an unofficial community tool and is not affiliated with Roblox Corporation or the Blox Fruits developers.
          </p>
          <p className="mt-2">
            Trade values reflect community consensus as of Update 31 (2026). Use at your own risk — always double-check before agreeing to a trade.
          </p>
        </div>
      </footer>

      {/* SEO SCHEMA: WebSite + SoftwareApplication */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebApplication",
            name: "BloxFruitsCalculator",
            url: "https://bloxfruitscalculator.com",
            applicationCategory: "GameApplication",
            operatingSystem: "Any (Browser)",
            description:
              "Free Blox Fruits Trade Calculator — instant W/F/L verdicts for any Roblox Blox Fruits trade. No signup or credit card required.",
            offers: {
              "@type": "Offer",
              price: "0",
              priceCurrency: "USD",
            },
            featureList: [
              "Trade Calculator (W/F/L)",
              "Full Value List with search & filter",
              "Mastery Calculator",
              "Dealer Stock Tracker",
              "Blox Fruits Tier List",
              "Scam warnings",
            ],
          }),
        }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              {
                "@type": "ListItem",
                position: 1,
                name: "Home",
                item: "https://bloxfruitscalculator.com/",
              },
              {
                "@type": "ListItem",
                position: 2,
                name: "Blox Fruits Calculator",
                item: "https://bloxfruitscalculator.com/calculator",
              },
            ],
          }),
        }}
      />
    </div>
  );
}
