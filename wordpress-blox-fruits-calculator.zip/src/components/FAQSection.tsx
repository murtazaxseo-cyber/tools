interface FAQ {
  q: string;
  a: string;
}

const FAQS: FAQ[] = [
  {
    q: "What is a Blox Fruits Calculator?",
    a: "A Blox Fruits Calculator is a free trading tool that compares the value of two trade offers in the Roblox game Blox Fruits. By entering the fruits on each side, the calculator instantly tells you if the deal is a WIN, FAIR or LOSE based on community-reported trade values, demand and rarity.",
  },
  {
    q: "How does the W/F/L verdict work?",
    a: "We add up the trade value of every fruit on each side, multiply by quantity, and compare the totals. If the gap between the lower and higher side is within 7%, the trade is marked FAIR. Anything beyond that is a WIN or LOSS depending on which side you are giving. We also surface a demand score (1-10) to factor in liquidity — high-demand fruits are easier to trade even if value is similar.",
  },
  {
    q: "Are the values in this calculator accurate?",
    a: "Yes. Our values reflect community consensus from Roblox trading servers, the Blox Fruits Wiki, and recent updates through Update 31 (2026). Demand scores update weekly, and we re-verify the entire list after every major patch. No signup or credit card is needed.",
  },
  {
    q: "What's the difference between Physical and Permanent value?",
    a: "Physical Blox Fruits are tradeable items you can swap with other players. Permanent versions are locked to your account and cannot be traded. Because of their tradeability and limited supply, physical fruits trade at a fraction (often 10-50%) of the permanent value. Use the toggle above the calculator to switch between the two valuations.",
  },
  {
    q: "Which Blox Fruit has the highest trade value right now?",
    a: "As of Update 31, Dragon (West) leads the trading market with a permanent value of ~2.9B Belì. Kitsune, Tiger, Leopard and Control follow closely. Mythical beasts dominate the top of the value list because of their rarity and PvP power.",
  },
  {
    q: "Do you need a Roblox account to use this tool?",
    a: "Nope. The entire Blox Fruits Calculator works straight in your browser. No login, no signup, no credit card and no Roblox account required. You can use it on any device — desktop, tablet or phone.",
  },
  {
    q: "How often are the values updated?",
    a: "We re-verify fruit demand scores weekly and run a full re-roll after every major patch. The current list reflects Update 31 (January 2026).",
  },
  {
    q: "Can I use this calculator on my phone?",
    a: "Yes. This tool is fully responsive and works on iOS, Android, and any modern mobile browser. You can compare trade offers in the Roblox Café right from your phone.",
  },
  {
    q: "What Blox Fruits tools are included?",
    a: "You get a Trade Calculator (W/F/L), a full Value List with search and filter, a Mastery Calculator for grinding, a Dealer Stock Tracker with live countdown, and a Tier List for PvP. Everything a Blox Fruits trader needs — for free.",
  },
  {
    q: "How do I avoid Blox Fruits trade scams?",
    a: "Never trade first, never use middlemen, never split trades, never click links sent by traders, and never cross-trade (real money, UGCs, other game items). Always check this calculator before accepting an offer.",
  },
];

export default function FAQSection() {
  return (
    <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-4 shadow-xl backdrop-blur sm:p-6" aria-label="Frequently Asked Questions">
      <header className="mb-4">
        <h2 className="flex items-center gap-2 text-xl font-bold text-white sm:text-2xl">
          <span aria-hidden="true">❓</span> Blox Fruits Calculator — FAQ
        </h2>
        <p className="mt-1 text-sm text-slate-400">
          Everything you need to know about using our free Blox Fruits trade calculator.
        </p>
      </header>

      <div className="space-y-2">
        {FAQS.map((item, i) => (
          <details key={i} className="rounded-xl border border-white/10 bg-slate-800/40 p-3 open:bg-slate-800/70">
            <summary className="cursor-pointer text-sm font-semibold text-white">
              {item.q}
            </summary>
            <p className="mt-2 text-sm leading-relaxed text-slate-300">
              {item.a}
            </p>
          </details>
        ))}
      </div>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            mainEntity: FAQS.map((f) => ({
              "@type": "Question",
              name: f.q,
              acceptedAnswer: {
                "@type": "Answer",
                text: f.a,
              },
            })),
          }),
        }}
      />
    </section>
  );
}
