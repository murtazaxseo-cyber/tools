import { useMemo, useState } from "react";
import { MASTERY_SOURCES, computeMastery } from "../data/mastery";

export default function MasteryCalculator() {
  const [currentLevel, setCurrentLevel] = useState(150);
  const [targetLevel, setTargetLevel] = useState(400);
  const [sourceId, setSourceId] = useState(MASTERY_SOURCES[0].id);
  const [twoXPass, setTwoXPass] = useState(true);
  const [masteryActive, setMasteryActive] = useState(false);

  const result = useMemo(
    () => computeMastery({ currentLevel, targetLevel, sourceId, twoXPass, masteryActive }),
    [currentLevel, targetLevel, sourceId, twoXPass, masteryActive]
  );

  return (
    <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-4 shadow-xl backdrop-blur sm:p-6" aria-label="Mastery Calculator">
      <header className="mb-4">
        <h2 className="flex items-center gap-2 text-xl font-bold text-white sm:text-2xl">
          <span aria-hidden="true">🎯</span> Mastery Calculator
        </h2>
        <p className="mt-1 text-sm text-slate-400">
          Plan your grind sessions — pick your current and target mastery level to see real-time XP requirements.
        </p>
      </header>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <Field label="Current Mastery Level">
          <input
            type="number"
            min={1}
            max={600}
            value={currentLevel}
            onChange={(e) => setCurrentLevel(Math.max(1, Math.min(600, Number(e.target.value) || 1)))}
            className="w-full rounded-lg border border-white/10 bg-slate-800 px-3 py-2 text-base font-semibold text-white"
          />
        </Field>
        <Field label="Target Mastery Level">
          <input
            type="number"
            min={1}
            max={600}
            value={targetLevel}
            onChange={(e) => setTargetLevel(Math.max(1, Math.min(600, Number(e.target.value) || 1)))}
            className="w-full rounded-lg border border-white/10 bg-slate-800 px-3 py-2 text-base font-semibold text-white"
          />
        </Field>
      </div>

      <Field label="Best XP Source">
        <select
          value={sourceId}
          onChange={(e) => setSourceId(e.target.value)}
          className="w-full rounded-lg border border-white/10 bg-slate-800 px-3 py-2 text-sm text-white"
        >
          {MASTERY_SOURCES.map((s) => (
            <option key={s.id} value={s.id}>
              {s.emoji} {s.name} (~{s.xpPerHour.toLocaleString()} XP/h)
            </option>
          ))}
        </select>
      </Field>

      <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
        <Toggle label="Use 2x Mastery Gamepass" checked={twoXPass} onChange={setTwoXPass} emoji="🎟️" />
        <Toggle label="Mastery boost active (event)" checked={masteryActive} onChange={setMasteryActive} emoji="⚡" />
      </div>

      <div className="mt-5 grid grid-cols-2 gap-2 sm:grid-cols-4">
        <Stat label="Levels" value={result.levelsToGain.toString()} />
        <Stat label="XP Needed" value={result.xpNeeded.toLocaleString()} />
        <Stat label="XP/min" value={Math.round(result.xpPerMin).toLocaleString()} />
        <Stat label="Hours" value={result.hoursNeeded.toFixed(1)} />
      </div>

      <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
        <Stat label="Days at 2 hours/day" value={result.daysAt2h.toFixed(1)} />
        <Stat label="Days at 4 hours/day" value={(result.daysAt2h / 2).toFixed(1)} />
      </div>
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="mt-3 block">
      <span className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-400">{label}</span>
      {children}
    </label>
  );
}

function Toggle({ label, checked, onChange, emoji }: { label: string; checked: boolean; onChange: (v: boolean) => void; emoji: string }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      aria-pressed={checked}
      className={`flex items-center justify-between rounded-lg border p-3 text-left text-sm transition ${checked ? "border-emerald-400/40 bg-emerald-500/10 text-emerald-200" : "border-white/10 bg-slate-800 text-slate-300 hover:bg-slate-700"}`}
    >
      <span className="flex items-center gap-2 font-semibold">
        <span aria-hidden="true">{emoji}</span> {label}
      </span>
      <span className="font-bold">{checked ? "ON" : "OFF"}</span>
    </button>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-slate-800/60 p-3">
      <p className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">{label}</p>
      <p className="mt-0.5 font-mono text-lg font-bold text-white">{value}</p>
    </div>
  );
}
