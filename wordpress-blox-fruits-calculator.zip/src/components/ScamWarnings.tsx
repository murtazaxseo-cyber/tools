const SCAMS = [
  {
    title: '"Gifting" & Robux on Another Account',
    body: 'Scammers claim there is a "glitch" preventing them from storing permanent fruits, so they ask you to trade first. There is no such glitch. Never trade first.',
  },
  {
    title: "Middleman Scams",
    body: 'A "trusted" middleman offering to hold your items during a trade is almost certainly the scammer or their alt. Real middlemen are nearly nonexistent in casual trading — never use one.',
  },
  {
    title: "Cross-Trading Scams",
    body: 'Exchanging Blox Fruits items for real money, Discord Nitro, or items from other games violates Roblox ToS and offers zero protection. Stick to official in-game trading.',
  },
  {
    title: "Double-Trade Scams",
    body: 'When someone insists on splitting a trade into multiple steps, they almost always vanish after receiving the first part. Always complete trades in a single window.',
  },
  {
    title: "Scam Links & Phishing",
    body: 'Fake Roblox or trade-site links can steal your login, fruits, and Robux. Never click trade-related links in DMs. Always log in at roblox.com only.',
  },
];

export default function ScamWarnings() {
  return (
    <section className="rounded-2xl border border-amber-400/20 bg-amber-500/5 p-4 shadow-xl backdrop-blur sm:p-6" aria-label="Trading Scam Warnings">
      <header className="mb-4">
        <h2 className="flex items-center gap-2 text-xl font-bold text-white sm:text-2xl">
          <span aria-hidden="true">⚠️</span> Avoid These Blox Fruits Trade Scams
        </h2>
        <p className="mt-1 text-sm text-slate-300">
          Knowing the patterns is the best defense. Use this calculator before accepting any trade.
        </p>
      </header>

      <ul className="grid grid-cols-1 gap-2 md:grid-cols-2">
        {SCAMS.map((s) => (
          <li key={s.title} className="rounded-xl border border-amber-400/15 bg-slate-900/50 p-3">
            <h3 className="text-sm font-bold text-amber-200">{s.title}</h3>
            <p className="mt-1 text-xs leading-relaxed text-slate-300">{s.body}</p>
          </li>
        ))}
      </ul>

      <div className="mt-4 rounded-xl border border-emerald-400/20 bg-emerald-500/5 p-3">
        <h3 className="text-sm font-bold text-emerald-200">Pro tip — always check the W/F/L verdict</h3>
        <p className="mt-1 text-xs text-slate-300">
          Before you accept any trade, run it through our calculator. If the verdict isn't FAIR or WIN for you, decline. It takes 10 seconds and saves you from getting scammed.
        </p>
      </div>
    </section>
  );
}
