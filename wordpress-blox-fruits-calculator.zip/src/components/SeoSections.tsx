import { FRUITS } from "../data/fruits";
import { formatValue } from "../data/fruits";

const HOW_TO_STEPS = [
  {
    n: 1,
    title: "Open the trade calculator",
    body: 'Scroll up to the ⚖️ Trade Calculator section — the main tool on this page. Select "Permanent" if you trade in-game fruits, or "Physical" if you trade stored fruits.',
  },
  {
    n: 2,
    title: "Add fruits to your offer",
    body: "Click + Add fruit on the left (Your Offer / You Give) side and pick the fruit you're giving. Set the quantity with the number input. Repeat for every fruit you give.",
  },
  {
    n: 3,
    title: "Add fruits to their offer",
    body: "Repeat on the right side (Their Offer / You Receive). The calculator updates in real-time — no submit button needed.",
  },
  {
    n: 4,
    title: "Read the W/F/L verdict",
    body: "The verdict bar shows WIN, FAIR, or LOSE plus the absolute Belì gap. Anything outside ±7% of equal value is flagged. A trade is fair only if values are within 7% of each other.",
  },
  {
    n: 5,
    title: "Check the demand score",
    body: "Each fruit shows a 1-10 demand score. High-demand fruits (8-10) trade easier and faster. Low-demand fruits (1-3) may be hard to offload even at the listed value.",
  },
];

const TOP_TOOLS = [
  { name: "Trade Calculator", emoji: "⚖️", desc: "W/F/L verdict for multi-fruit offers with demand scoring." },
  { name: "Value List", emoji: "📊", desc: "Sortable list of all 38 fruits with physical & permanent values." },
  { name: "Mastery Calculator", emoji: "🎯", desc: "Plan your grind: time, XP and days to next mastery level." },
  { name: "Stock Tracker", emoji: "⏰", desc: "Live countdown for the in-game dealer restock rotation." },
  { name: "Tier List", emoji: "🏆", desc: "S-tier to D-tier fruit ranking for PvP and grinding." },
  { name: "Scam Warnings", emoji: "⚠️", desc: "Patterns to recognize and avoid during in-game trades." },
];

export default function SeoSections() {
  const top5 = [...FRUITS].sort((a, b) => b.permanentValue - a.permanentValue).slice(0, 5);

  return (
    <>
      <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-4 shadow-xl backdrop-blur sm:p-6" aria-label="How to use the calculator">
        <header className="mb-4">
          <h2 className="flex items-center gap-2 text-xl font-bold text-white sm:text-2xl">
            <span aria-hidden="true">📘</span> How to Use the Blox Fruits Calculator
          </h2>
          <p className="mt-1 text-sm text-slate-400">
            Five quick steps to test any Blox Fruits trade for fairness.
          </p>
        </header>
        <ol className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-1">
          {HOW_TO_STEPS.map((s) => (
            <li key={s.n} className="rounded-xl border border-white/10 bg-slate-800/40 p-4">
              <div className="flex items-start gap-3">
                <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500 to-indigo-600 text-base font-black text-white shadow">
                  {s.n}
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">{s.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-slate-300">{s.body}</p>
                </div>
              </div>
            </li>
          ))}
        </ol>
      </section>

      <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-4 shadow-xl backdrop-blur sm:p-6" aria-label="Top trade values right now">
        <header className="mb-4 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="flex items-center gap-2 text-xl font-bold text-white sm:text-2xl">
              <span aria-hidden="true">💎</span> Top Blox Fruits Values Right Now
            </h2>
            <p className="mt-1 text-sm text-slate-400">
              Highest trade values across all rarities — last refreshed for 2026.
            </p>
          </div>
        </header>
        <div className="overflow-x-auto rounded-xl border border-white/10">
          <table className="min-w-full text-left text-sm">
            <thead className="bg-slate-800/80 text-[11px] uppercase tracking-wider text-slate-300">
              <tr>
                <th scope="col" className="px-3 py-2.5">Fruit</th>
                <th scope="col" className="px-3 py-2.5">Rarity</th>
                <th scope="col" className="px-3 py-2.5 text-right">Permanent Value</th>
                <th scope="col" className="px-3 py-2.5 text-right">Physical Value</th>
                <th scope="col" className="px-3 py-2.5 text-center">Demand</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {top5.map((f) => (
                <tr key={f.id} className="bg-slate-900/40">
                  <td className="px-3 py-2.5 font-semibold text-white">
                    <span className="mr-2 text-xl" aria-hidden="true">{f.emoji}</span>
                    {f.name}
                  </td>
                  <td className="px-3 py-2.5 text-slate-300">{f.rarity}</td>
                  <td className="px-3 py-2.5 text-right font-mono font-bold text-fuchsia-300">{formatValue(f.permanentValue)}</td>
                  <td className="px-3 py-2.5 text-right font-mono font-bold text-sky-300">{formatValue(f.physicalValue)}</td>
                  <td className="px-3 py-2.5 text-center font-bold text-white">{f.demand}/10</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-4 shadow-xl backdrop-blur sm:p-6" aria-label="All tools on this page">
        <header className="mb-4">
          <h2 className="flex items-center gap-2 text-xl font-bold text-white sm:text-2xl">
            <span aria-hidden="true">🧰</span> All Blox Fruits Tools on This Page
          </h2>
          <p className="mt-1 text-sm text-slate-400">
            One page, six tools. No signup, no credit card, no Roblox login required.
          </p>
        </header>
        <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {TOP_TOOLS.map((t) => (
            <li key={t.name} className="rounded-xl border border-white/10 bg-slate-800/40 p-3">
              <div className="flex items-center gap-2">
                <span className="text-xl" aria-hidden="true">{t.emoji}</span>
                <h3 className="text-sm font-bold text-white">{t.name}</h3>
              </div>
              <p className="mt-1 text-xs text-slate-300">{t.desc}</p>
            </li>
          ))}
        </ul>
      </section>
    </>
  );
}
