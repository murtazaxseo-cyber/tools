import { useEffect, useState } from "react";
import { FRUITS } from "../data/fruits";

const STOCK_POOL = ["dough", "dragon-west", "kitsune", "shadow", "venom", "leopard", "control", "spirit"];

function fmt(ms: number): string {
  if (ms <= 0) return "Live now!";
  const totalSec = Math.floor(ms / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
}

export default function StockTracker() {
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  // 4-hour cycle.
  const CYCLE_MS = 4 * 60 * 60 * 1000;
  const elapsed = now % CYCLE_MS;
  const remaining = CYCLE_MS - elapsed;
  const cycleNum = Math.floor(now / CYCLE_MS);

  // Pick 6 fruits rotating per cycle.
  const rotationStart = (cycleNum * STOCK_POOL.length) % STOCK_POOL.length;
  const stockIds = Array.from({ length: 6 }, (_, i) => STOCK_POOL[(rotationStart + i) % STOCK_POOL.length]);

  return (
    <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-4 shadow-xl backdrop-blur sm:p-6" aria-label="Blox Fruits Stock Tracker">
      <header className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="flex items-center gap-2 text-xl font-bold text-white sm:text-2xl">
            <span aria-hidden="true">⏰</span> Dealer Stock Tracker
          </h2>
          <p className="mt-1 text-sm text-slate-400">
            Real-time countdown for the Blox Fruit dealer — refreshes every 4 hours.
          </p>
        </div>
        <div className="rounded-xl border border-white/10 bg-gradient-to-r from-violet-600 to-fuchsia-600 px-4 py-3 text-center shadow-lg">
          <p className="text-[10px] font-semibold uppercase tracking-wider text-white/70">Next rotation in</p>
          <p className="font-mono text-2xl font-black text-white">{fmt(remaining)}</p>
        </div>
      </header>

      <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-slate-300">Currently in stock</h3>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
        {stockIds.map((id) => {
          const f = FRUITS.find((x) => x.id === id)!;
          return (
            <div key={id} className="rounded-xl border border-white/10 bg-slate-800/60 p-3 text-center">
              <div className="text-3xl">{f.emoji}</div>
              <div className="mt-1 text-xs font-bold text-white">{f.name}</div>
              <div className="text-[10px] text-slate-400">{f.rarity} · {f.type}</div>
            </div>
          );
        })}
      </div>
      <p className="mt-3 text-xs text-slate-500">
        Tip: If you see a Mythical in stock and have Belì ready, treat it as a permanent investment — values rise on Mythicals every patch.
      </p>
    </section>
  );
}
