import { FRUITS } from "../data/fruits";
import { formatValue } from "../data/fruits";

interface Tier {
  letter: string;
  label: string;
  color: string;
  description: string;
  fruitIds: string[];
}

const TIERS: Tier[] = [
  {
    letter: "S",
    label: "Mythical Beasts",
    color: "from-fuchsia-500 to-purple-600",
    description: "Top of the meta for both PvP and grinding",
    fruitIds: ["dragon-west", "kitsune", "tiger", "leopard", "yeti"],
  },
  {
    letter: "A",
    label: "Elite Mythicals",
    color: "from-violet-500 to-indigo-600",
    description: "Strong PvP combos & bossing potential",
    fruitIds: ["control", "dough", "venom", "shadow", "t-rex", "gas"],
  },
  {
    letter: "B",
    label: "Solid Picks",
    color: "from-sky-500 to-blue-600",
    description: "Reliable for grinding, decent PvP",
    fruitIds: ["lightning", "buddha", "spirit", "pain", "mammoth", "gravity"],
  },
  {
    letter: "C",
    label: "Niche",
    color: "from-emerald-500 to-teal-600",
    description: "Useful in specific scenarios",
    fruitIds: ["phoenix", "sound", "magma", "blizzard", "creation"],
  },
  {
    letter: "D",
    label: "Filler",
    color: "from-slate-500 to-slate-700",
    description: "Trade away for higher tiers",
    fruitIds: ["dark", "diamond", "ghost", "rubber", "spider"],
  },
];

export default function TierList() {
  return (
    <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-4 shadow-xl backdrop-blur sm:p-6" aria-label="Blox Fruits Tier List">
      <header className="mb-4">
        <h2 className="flex items-center gap-2 text-xl font-bold text-white sm:text-2xl">
          <span aria-hidden="true">🏆</span> Blox Fruits Tier List 2026
        </h2>
        <p className="mt-1 text-sm text-slate-400">
          Every Blox Fruit ranked for PvP, grinding, and trading value. Updated after every major game patch.
        </p>
      </header>

      <div className="space-y-3">
        {TIERS.map((tier) => (
          <div key={tier.letter} className="overflow-hidden rounded-xl border border-white/10 bg-slate-800/40">
            <div className={`flex items-center justify-between gap-3 bg-gradient-to-r ${tier.color} px-3 py-2.5 sm:px-4`}>
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/15 text-base font-black text-white shadow-md sm:h-10 sm:w-10 sm:text-lg">
                  {tier.letter}
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white sm:text-base">{tier.label}</h3>
                  <p className="text-[10px] text-white/80 sm:text-xs">{tier.description}</p>
                </div>
              </div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-white/80">
                {tier.fruitIds.length} fruits
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2 p-3 sm:grid-cols-3 lg:grid-cols-6">
              {tier.fruitIds.map((fid) => {
                const f = FRUITS.find((x) => x.id === fid);
                if (!f) return null;
                return (
                  <div key={fid} className="flex items-center gap-2 rounded-lg border border-white/5 bg-slate-900/50 p-2">
                    <span className="text-2xl" aria-hidden="true">{f.emoji}</span>
                    <div className="min-w-0">
                      <div className="truncate text-xs font-bold text-white">{f.name}</div>
                      <div className="text-[10px] text-slate-400">
                        {f.demand}/10 · <span className="font-mono">{formatValue(f.permanentValue)}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
