import { useMemo, useState } from "react";
import { calculateVerdict, itemRarity, type TradeItem, type TradeMode } from "../utils/tradeMath";
import { ALL_ITEMS } from "../utils/tradeMath";
import { formatExact, formatValue } from "../data/fruits";

interface Props {
  initialMode?: TradeMode;
}

export default function TradeCalculator({ initialMode = "permanent" }: Props) {
  const [mode, setMode] = useState<TradeMode>(initialMode);
  const [give, setGive] = useState<TradeItem[]>([
    { id: "dough", quantity: 1 },
  ]);
  const [receive, setReceive] = useState<TradeItem[]>([
    { id: "shadow", quantity: 1 },
  ]);

  const verdict = useMemo(() => calculateVerdict(give, receive, mode), [give, receive, mode]);

  // sort items for the dropdown — top tier first
  const sortedItems = useMemo(
    () => [...ALL_ITEMS].sort((a, b) => {
      const av = mode === "permanent" ? (a.kind === "fruit" ? a.permanentValue : a.value) : (a.kind === "fruit" ? a.physicalValue : a.value);
      const bv = mode === "permanent" ? (b.kind === "fruit" ? b.permanentValue : b.value) : (b.kind === "fruit" ? b.physicalValue : b.value);
      return bv - av;
    }),
    [mode]
  );

  const updateItem = (side: "give" | "receive", idx: number, patch: Partial<TradeItem>) => {
    const setter = side === "give" ? setGive : setReceive;
    setter((prev) => prev.map((it, i) => (i === idx ? { ...it, ...patch } : it)));
  };

  const removeItem = (side: "give" | "receive", idx: number) => {
    const setter = side === "give" ? setGive : setReceive;
    setter((prev) => prev.filter((_, i) => i !== idx));
  };

  const addItem = (side: "give" | "receive") => {
    const setter = side === "give" ? setGive : setReceive;
    setter((prev) => [...prev, { id: "rocket", quantity: 1 }]);
  };

  const swapSides = () => {
    setGive(receive);
    setReceive(give);
  };

  const clearAll = () => {
    setGive([]);
    setReceive([]);
  };

  const loadSample = () => {
    setMode("permanent");
    setGive([{ id: "dough", quantity: 1 }]);
    setReceive([{ id: "kitsune", quantity: 1 }]);
  };

  const verdictColors: Record<string, string> = {
    win: "from-emerald-500/20 to-green-500/10 border-emerald-400/40 text-emerald-300",
    fair: "from-sky-500/20 to-cyan-500/10 border-sky-400/40 text-sky-200",
    lose: "from-rose-500/20 to-pink-500/10 border-rose-400/40 text-rose-300",
    empty: "from-slate-700/40 to-slate-800/30 border-slate-600/40 text-slate-300",
  };

  return (
    <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-4 shadow-xl backdrop-blur sm:p-6" aria-label="Blox Fruits Trade Calculator">
      <header className="mb-4 flex flex-col gap-3 sm:mb-6 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-bold text-white sm:text-2xl">
            <span aria-hidden="true">⚖️</span> Trade Calculator
          </h2>
          <p className="mt-1 text-sm text-slate-400">
            Add fruits on both sides and instantly see if the trade is a W, F or L.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex rounded-lg border border-white/10 bg-slate-800 p-1 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setMode("permanent")}
              aria-pressed={mode === "permanent"}
              className={`rounded-md px-3 py-1.5 transition ${mode === "permanent" ? "bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow" : "text-slate-300 hover:text-white"}`}
            >
              Permanent
            </button>
            <button
              type="button"
              onClick={() => setMode("physical")}
              aria-pressed={mode === "physical"}
              className={`rounded-md px-3 py-1.5 transition ${mode === "physical" ? "bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow" : "text-slate-300 hover:text-white"}`}
            >
              Physical
            </button>
          </div>
          <button
            type="button"
            onClick={loadSample}
            className="rounded-lg border border-white/10 bg-slate-800 px-3 py-1.5 text-xs font-medium text-slate-300 transition hover:bg-slate-700"
          >
            Sample trade
          </button>
          <button
            type="button"
            onClick={clearAll}
            className="rounded-lg border border-white/10 bg-slate-800 px-3 py-1.5 text-xs font-medium text-slate-300 transition hover:bg-rose-600/30 hover:text-rose-200"
          >
            Clear
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <TradeSide
          side="give"
          title="🟪 Your Offer (You Give)"
          items={give}
          mode={mode}
          items_catalog={sortedItems}
          onChange={updateItem}
          onRemove={removeItem}
          onAdd={addItem}
          total={verdict.giveValue}
          accent="from-violet-500 to-fuchsia-500"
        />
        <TradeSide
          side="receive"
          title="🟦 Their Offer (You Receive)"
          items={receive}
          mode={mode}
          items_catalog={sortedItems}
          onChange={updateItem}
          onRemove={removeItem}
          onAdd={addItem}
          total={verdict.receiveValue}
          accent="from-sky-500 to-cyan-500"
        />
      </div>

      <div className="mt-4 flex items-center justify-center">
        <button
          type="button"
          onClick={swapSides}
          className="rounded-full border border-white/15 bg-slate-800/80 px-4 py-2 text-xs font-semibold text-slate-200 shadow transition hover:bg-slate-700"
          aria-label="Swap offer sides"
        >
          <span aria-hidden="true">⇅</span> Swap sides
        </button>
      </div>

      <div className={`mt-6 rounded-2xl border bg-gradient-to-r ${verdictColors[verdict.verdict]} p-4 sm:p-6`} role="status" aria-live="polite">
        <div className="flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-center">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider opacity-80">W/F/L Verdict</p>
            <p className="mt-1 text-2xl font-black sm:text-3xl">
              {verdict.verdict === "win" && "🟢 WIN"}
              {verdict.verdict === "lose" && "🔴 LOSE"}
              {verdict.verdict === "fair" && "🟡 FAIR"}
              {verdict.verdict === "empty" && "Add items"}
            </p>
            <p className="mt-1 text-sm font-medium opacity-90">{verdict.label}</p>
          </div>
          <div className="grid grid-cols-3 gap-3 text-center">
            <div>
              <p className="text-[10px] font-semibold uppercase opacity-70">You give</p>
              <p className="font-mono text-base font-bold">{formatValue(verdict.giveValue)}</p>
            </div>
            <div>
              <p className="text-[10px] font-semibold uppercase opacity-70">You get</p>
              <p className="font-mono text-base font-bold">{formatValue(verdict.receiveValue)}</p>
            </div>
            <div>
              <p className="text-[10px] font-semibold uppercase opacity-70">Gap</p>
              <p className="font-mono text-base font-bold">{formatValue(verdict.gap)}</p>
            </div>
          </div>
        </div>

        <VerdictGauge verdict={verdict.verdict} ratio={verdict.ratio} />
      </div>

      <details className="mt-6 rounded-xl border border-white/10 bg-slate-800/40 p-3 text-sm text-slate-300">
        <summary className="cursor-pointer text-xs font-semibold uppercase tracking-wider text-slate-400">
          How is the verdict calculated?
        </summary>
        <div className="mt-3 space-y-2 leading-relaxed">
          <p>
            We add up the {mode === "permanent" ? "permanent " : "physical "}Belì value of every fruit on each side, multiply by quantity, and compare the totals. A trade is flagged <strong>fair</strong> when the lower-valued side is within 7% of the higher side. Anything beyond that is a <strong>win</strong> or a <strong>loss</strong> depending on which side you are giving.
          </p>
          <p>
            Tip: <strong>demand</strong> matters too. A fruit with demand 10 may move slower if buyers are scarce — open the demand breakdown below each fruit to see the full picture.
          </p>
        </div>
      </details>
    </section>
  );
}

interface SideProps {
  side: "give" | "receive";
  title: string;
  items: TradeItem[];
  mode: TradeMode;
  items_catalog: ReturnType<typeof Object>;
  onChange: (side: "give" | "receive", idx: number, patch: Partial<TradeItem>) => void;
  onRemove: (side: "give" | "receive", idx: number) => void;
  onAdd: (side: "give" | "receive") => void;
  total: number;
  accent: string;
}

function TradeSide({ side, title, items, mode, items_catalog, onChange, onRemove, onAdd, total, accent }: SideProps) {
  return (
    <div className="rounded-2xl border border-white/10 bg-slate-800/40 p-4">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-sm font-bold text-white">{title}</h3>
        <span className={`rounded-full bg-gradient-to-r ${accent} px-3 py-1 font-mono text-xs font-bold text-white shadow-md`}>
          {formatValue(total)}
        </span>
      </div>
      <div className="space-y-2">
        {items.length === 0 && (
          <p className="rounded-lg border border-dashed border-white/10 p-4 text-center text-xs text-slate-500">
            No items on this side yet. Add one below.
          </p>
        )}
        {items.map((entry, idx) => {
          const item = (items_catalog as any[]).find((x) => x.id === entry.id);
          const value = item
            ? (mode === "permanent"
                ? (item.kind === "fruit" ? item.permanentValue : item.value)
                : (item.kind === "fruit" ? item.physicalValue : item.value))
            : 0;
          const trend = item?.trend ?? "stable";
          return (
            <div key={idx} className="grid grid-cols-12 items-center gap-2 rounded-xl border border-white/10 bg-slate-900/60 p-2">
              <select
                value={entry.id}
                onChange={(e) => onChange(side, idx, { id: e.target.value })}
                aria-label={`${side} item ${idx + 1}`}
                className="col-span-7 rounded-lg border border-white/10 bg-slate-800 px-2 py-2 text-sm text-white focus:border-violet-400 focus:outline-none"
              >
                {(items_catalog as any[]).map((it) => (
                  <option key={it.id} value={it.id}>
                    {it.emoji} {it.name} · {formatValue(
                      mode === "permanent"
                        ? (it.kind === "fruit" ? it.permanentValue : it.value)
                        : (it.kind === "fruit" ? it.physicalValue : it.value)
                    )}
                  </option>
                ))}
              </select>
              <input
                type="number"
                min={1}
                value={entry.quantity}
                onChange={(e) => onChange(side, idx, { quantity: Math.max(1, Number(e.target.value) || 1) })}
                aria-label="quantity"
                className="col-span-2 rounded-lg border border-white/10 bg-slate-800 px-1 py-2 text-center text-sm text-white"
              />
              <span className={`col-span-2 text-center text-[10px] font-bold uppercase ${
                trend === "up" ? "text-emerald-400" : trend === "down" ? "text-rose-400" : "text-slate-400"
              }`}>
                {trend === "up" ? "↑" : trend === "down" ? "↓" : "→"} {(item?.demand ?? 0)}/10
              </span>
              <button
                type="button"
                onClick={() => onRemove(side, idx)}
                aria-label="remove item"
                className="col-span-1 rounded-lg bg-slate-700 py-2 text-xs text-rose-300 transition hover:bg-rose-600 hover:text-white"
              >
                ✕
              </button>
              <div className="col-span-12 mt-1 flex items-center justify-between text-[11px] text-slate-400">
                <span>{itemRarity(entry.id)}</span>
                <span className="font-mono">
                  Unit: {formatValue(value)} · Total: <strong className="text-white">{formatValue(value * entry.quantity)}</strong>
                </span>
                <span>{formatExact(value)} Belì</span>
              </div>
            </div>
          );
        })}
      </div>
      <button
        type="button"
        onClick={() => onAdd(side)}
        className="mt-3 w-full rounded-xl border border-dashed border-violet-400/40 bg-violet-500/5 px-3 py-3 text-sm font-semibold text-violet-200 transition hover:bg-violet-500/15"
      >
        + Add {side === "give" ? "fruit" : "fruit"} to my {side === "give" ? "give" : "receive"} side
      </button>
    </div>
  );
}

function VerdictGauge({ verdict, ratio }: { verdict: string; ratio: number }) {
  const color =
    verdict === "win" ? "#22c55e" : verdict === "lose" ? "#f43f5e" : verdict === "fair" ? "#38bdf8" : "#64748b";

  return (
    <div className="mt-4">
      <div className="relative h-3 overflow-hidden rounded-full bg-slate-800">
        <div
          className="absolute inset-y-0 left-0 transition-all"
          style={{
            width: `${verdict === "lose" ? Math.min(100, ratio * 25) : Math.min(100, 50 + (ratio > 1 ? Math.min(50, (ratio - 1) * 25) : 0))}%`,
            background: color,
          }}
        />
      </div>
      <div className="mt-2 flex justify-between text-[10px] uppercase tracking-wider text-slate-400">
        <span>You Lose</span>
        <span>Fair</span>
        <span>You Win</span>
      </div>
    </div>
  );
}
