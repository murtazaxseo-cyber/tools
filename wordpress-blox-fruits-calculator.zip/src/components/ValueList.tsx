import { useMemo, useState } from "react";
import { FRUITS, type Fruit, type Rarity, type Trend } from "../data/fruits";
import { formatValue } from "../data/fruits";

interface Props {
  initialFilter?: Rarity | "all";
}

const RARITY_ORDER: Record<Rarity, number> = {
  Mythical: 0, Legendary: 1, Rare: 2, Uncommon: 3, Common: 4,
};

const TREND_ICON: Record<Trend, string> = { up: "↗", down: "↘", stable: "→" };
const TREND_COLOR: Record<Trend, string> = {
  up: "text-emerald-400 bg-emerald-500/10 border-emerald-400/30",
  down: "text-rose-400 bg-rose-500/10 border-rose-400/30",
  stable: "text-slate-300 bg-slate-700/30 border-slate-400/30",
};

export default function ValueList({ initialFilter = "all" }: Props) {
  const [filter, setFilter] = useState<Rarity | "all">(initialFilter);
  const [mode, setMode] = useState<"permanent" | "physical">("permanent");
  const [sort, setSort] = useState<"value" | "demand" | "rarity">("value");
  const [search, setSearch] = useState("");

  const list = useMemo(() => {
    let rows = [...FRUITS];
    if (filter !== "all") rows = rows.filter((f) => f.rarity === filter);
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      rows = rows.filter((f) => f.name.toLowerCase().includes(q));
    }
    rows.sort((a, b) => {
      if (sort === "value") {
        const av = mode === "permanent" ? a.permanentValue : a.physicalValue;
        const bv = mode === "permanent" ? b.permanentValue : b.physicalValue;
        return bv - av;
      }
      if (sort === "demand") return b.demand - a.demand;
      return RARITY_ORDER[a.rarity] - RARITY_ORDER[b.rarity];
    });
    return rows;
  }, [filter, sort, search, mode]);

  const totals = useMemo(() => {
    const top = list[0];
    const mythical = list.filter((f) => f.rarity === "Mythical").length;
    const totalDemand = Math.round(list.reduce((s, f) => s + f.demand, 0) / Math.max(1, list.length));
    return { top, mythical, totalDemand };
  }, [list]);

  return (
    <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-4 shadow-xl backdrop-blur sm:p-6" aria-label="Blox Fruits Value List">
      <header className="mb-4 sm:mb-6">
        <h2 className="flex items-center gap-2 text-xl font-bold text-white sm:text-2xl">
          <span aria-hidden="true">📊</span> Blox Fruits Value List
        </h2>
        <p className="mt-1 text-sm text-slate-400">
          Live trading values for all {FRUITS.length} fruits, sorted by demand and rarity. Updated for patch Update 31.
        </p>
      </header>

      <div className="mb-4 grid grid-cols-1 gap-2 sm:grid-cols-3">
        <Stat label="Mythical Fruits" value={totals.mythical.toString()} />
        <Stat label="Top Fruit" value={totals.top ? `${totals.top.emoji} ${totals.top.name}` : "—"} />
        <Stat label="Avg. Demand" value={`${totals.totalDemand}/10`} />
      </div>

      <div className="mb-4 grid grid-cols-1 gap-2 sm:grid-cols-3">
        <input
          type="search"
          placeholder="Search fruit (e.g. dragon, kitsune)..."
          aria-label="Search fruits"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="rounded-lg border border-white/10 bg-slate-800 px-3 py-2 text-sm text-white placeholder-slate-500 focus:border-violet-400 focus:outline-none"
        />
        <select
          value={sort}
          onChange={(e) => setSort(e.target.value as any)}
          aria-label="Sort"
          className="rounded-lg border border-white/10 bg-slate-800 px-3 py-2 text-sm text-white"
        >
          <option value="value">Sort by Value</option>
          <option value="demand">Sort by Demand</option>
          <option value="rarity">Sort by Rarity</option>
        </select>
        <div className="inline-flex rounded-lg border border-white/10 bg-slate-800 p-1 text-xs font-semibold">
          {(["all", "Mythical", "Legendary", "Rare", "Uncommon", "Common"] as const).map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setFilter(r)}
              aria-pressed={filter === r}
              className={`rounded-md px-2 py-1.5 transition ${filter === r ? "bg-violet-600 text-white shadow" : "text-slate-300 hover:text-white"}`}
            >
              {r === "all" ? "All" : r}
            </button>
          ))}
        </div>
      </div>

      <div className="mb-4 inline-flex rounded-lg border border-white/10 bg-slate-800 p-1 text-xs font-semibold">
        <button
          type="button"
          onClick={() => setMode("permanent")}
          aria-pressed={mode === "permanent"}
          className={`rounded-md px-3 py-1.5 transition ${mode === "permanent" ? "bg-indigo-600 text-white shadow" : "text-slate-300 hover:text-white"}`}
        >
          Permanent
        </button>
        <button
          type="button"
          onClick={() => setMode("physical")}
          aria-pressed={mode === "physical"}
          className={`rounded-md px-3 py-1.5 transition ${mode === "physical" ? "bg-indigo-600 text-white shadow" : "text-slate-300 hover:text-white"}`}
        >
          Physical
        </button>
      </div>

      <div className="overflow-x-auto rounded-xl border border-white/10">
        <table className="min-w-full text-left text-sm">
          <thead className="bg-slate-800/80 text-[11px] uppercase tracking-wider text-slate-300">
            <tr>
              <th scope="col" className="px-3 py-2.5">Fruit</th>
              <th scope="col" className="px-3 py-2.5">Type</th>
              <th scope="col" className="px-3 py-2.5">Rarity</th>
              <th scope="col" className="px-3 py-2.5 text-right">Value ({mode === "permanent" ? "Perm" : "Phys"})</th>
              <th scope="col" className="px-3 py-2.5 text-center">Demand</th>
              <th scope="col" className="px-3 py-2.5 text-center">Trend</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {list.map((fruit: Fruit) => {
              const value = mode === "permanent" ? fruit.permanentValue : fruit.physicalValue;
              return (
                <tr key={fruit.id} className="bg-slate-900/40 transition hover:bg-slate-800/60">
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xl" aria-hidden="true">{fruit.emoji}</span>
                      <div>
                        <div className="font-semibold text-white">{fruit.name}</div>
                        <div className="text-[10px] text-slate-500 line-clamp-1">{fruit.description}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-3 py-2.5 text-slate-300">{fruit.type}</td>
                  <td className="px-3 py-2.5">
                    <RarityBadge rarity={fruit.rarity} />
                  </td>
                  <td className="px-3 py-2.5 text-right font-mono font-semibold text-white">
                    {formatValue(value)}
                  </td>
                  <td className="px-3 py-2.5 text-center">
                    <DemandBar demand={fruit.demand} />
                  </td>
                  <td className="px-3 py-2.5 text-center">
                    <span className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-bold uppercase ${TREND_COLOR[fruit.trend]}`}>
                      <span aria-hidden="true">{TREND_ICON[fruit.trend]}</span>
                      {fruit.trend}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      {list.length === 0 && (
        <p className="rounded-lg border border-dashed border-white/10 p-6 text-center text-sm text-slate-500">
          No fruits match your search.
        </p>
      )}
    </section>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-slate-800/60 p-3">
      <p className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">{label}</p>
      <p className="mt-0.5 text-base font-bold text-white">{value}</p>
    </div>
  );
}

function RarityBadge({ rarity }: { rarity: Rarity }) {
  const colors: Record<Rarity, string> = {
    Mythical: "bg-fuchsia-500/15 text-fuchsia-300 border-fuchsia-400/30",
    Legendary: "bg-amber-500/15 text-amber-300 border-amber-400/30",
    Rare: "bg-sky-500/15 text-sky-300 border-sky-400/30",
    Uncommon: "bg-emerald-500/15 text-emerald-300 border-emerald-400/30",
    Common: "bg-slate-500/15 text-slate-300 border-slate-400/30",
  };
  return (
    <span className={`inline-block rounded-md border px-2 py-0.5 text-[10px] font-bold uppercase ${colors[rarity]}`}>
      {rarity}
    </span>
  );
}

function DemandBar({ demand }: { demand: number }) {
  const pct = (demand / 10) * 100;
  const color = demand >= 8 ? "from-emerald-400 to-green-500" : demand >= 5 ? "from-amber-400 to-orange-500" : "from-slate-400 to-slate-500";
  return (
    <div className="flex flex-col items-center gap-0.5">
      <div className="h-1.5 w-16 overflow-hidden rounded-full bg-slate-700">
        <div className={`h-full bg-gradient-to-r ${color}`} style={{ width: `${pct}%` }} />
      </div>
      <span className="text-[10px] font-bold text-white">{demand}/10</span>
    </div>
  );
}
