// Complete Blox Fruits database with values, demand, type, rarity
// Values in Beli - last updated for 2026 trading meta
export type Rarity = "Common" | "Uncommon" | "Rare" | "Legendary" | "Mythical";
export type FruitType = "Natural" | "Beast" | "Logia" | "Elemental";
export type Trend = "up" | "down" | "stable";

export interface Fruit {
  id: string;
  name: string;
  emoji: string;
  rarity: Rarity;
  type: FruitType;
  physicalValue: number; // in Beli
  permanentValue: number; // in Beli
  demand: number; // 1-10
  trend: Trend;
  description: string;
}

export const FRUITS: Fruit[] = [
  // ========== MYTHICAL ==========
  { id: "dragon-west", name: "Dragon (West)", emoji: "🐉", rarity: "Mythical", type: "Beast", physicalValue: 1_450_000_000, permanentValue: 2_900_000_000, demand: 10, trend: "up", description: "Strongest mythical fruit for PvP and grinding — combo king with flight in human form." },
  { id: "kitsune", name: "Kitsune", emoji: "🦊", rarity: "Mythical", type: "Beast", physicalValue: 290_000_000, permanentValue: 2_320_000_000, demand: 10, trend: "up", description: "Limited mythical with a devastating fox flurry — gorgeous effects, top-tier damage." },
  { id: "dragon-east", name: "Dragon (East)", emoji: "🐲", rarity: "Mythical", type: "Beast", physicalValue: 1_350_000_000, permanentValue: 2_700_000_000, demand: 9, trend: "stable", description: "Eastern dragon variant — flight, fire breath, and elite grinding stats." },
  { id: "leopard", name: "Leopard", emoji: "🐆", rarity: "Mythical", type: "Beast", physicalValue: 55_000_000, permanentValue: 1_690_000_000, demand: 9, trend: "up", description: "Beast form with rapid melee combos — meta for PvP and boss rushing." },
  { id: "tiger", name: "Tiger", emoji: "🐯", rarity: "Mythical", type: "Beast", physicalValue: 140_000_000, permanentValue: 2_210_000_000, demand: 8, trend: "stable", description: "Tiger-style melee combos — high burst on bosses and PvP duels." },
  { id: "yeti", name: "Yeti", emoji: "❄️", rarity: "Mythical", type: "Beast", physicalValue: 160_000_000, permanentValue: 1_740_000_000, demand: 10, trend: "stable", description: "Ice-typing beast — freezes enemies and deals heavy burst in combos." },
  { id: "gas", name: "Gas", emoji: "💨", rarity: "Mythical", type: "Natural", physicalValue: 75_000_000, permanentValue: 1_610_000_000, demand: 9, trend: "up", description: "AOE gas attacks scale into late game — top tier for grinding in crowded seas." },
  { id: "control", name: "Control", emoji: "🎮", rarity: "Mythical", type: "Natural", physicalValue: 165_000_000, permanentValue: 1_400_000_000, demand: 8, trend: "stable", description: "Mobility + zoning — fastest PvP movement fruit in the game." },
  { id: "dough", name: "Dough", emoji: "🍩", rarity: "Mythical", type: "Logia", physicalValue: 35_000_000, permanentValue: 1_450_000_000, demand: 10, trend: "up", description: "Famous for donut & scythe — one of the best ranged fruits in PvP." },
  { id: "venom", name: "Venom", emoji: "☠️", rarity: "Mythical", type: "Natural", physicalValue: 10_000_000, permanentValue: 1_300_000_000, demand: 8, trend: "stable", description: "Toxic logia — poisons enemies, melts bosses and grants invulnerability frames." },
  { id: "shadow", name: "Shadow", emoji: "🌑", rarity: "Mythical", type: "Natural", physicalValue: 7_000_000, permanentValue: 1_150_000_000, demand: 7, trend: "stable", description: "Teleporting dark-elemental — safe and fast mobility for any level." },
  { id: "t-rex", name: "T-Rex", emoji: "🦖", rarity: "Mythical", type: "Beast", physicalValue: 25_000_000, permanentValue: 850_000_000, demand: 7, trend: "up", description: "Dinosaur transformation — huge melee hitbox and crowd control." },
  { id: "spirit", name: "Spirit", emoji: "👻", rarity: "Mythical", type: "Natural", physicalValue: 10_000_000, permanentValue: 455_000_000, demand: 8, trend: "stable", description: "Scythe + bomb combo — high skill ceiling PvP fruit." },
  { id: "mammoth", name: "Mammoth", emoji: "🦣", rarity: "Mythical", type: "Beast", physicalValue: 10_000_000, permanentValue: 380_000_000, demand: 4, trend: "stable", description: "Slow but massive damage in awakened form — niche for bossing." },
  { id: "pain", name: "Pain", emoji: "🩸", rarity: "Mythical", type: "Natural", physicalValue: 10_000_000, permanentValue: 320_000_000, demand: 5, trend: "stable", description: "Curse damage-over-time — solid for PvP pressure and combos." },
  { id: "gravity", name: "Gravity", emoji: "🌀", rarity: "Mythical", type: "Natural", physicalValue: 10_000_000, permanentValue: 700_000_000, demand: 5, trend: "stable", description: "Pull enemies in for combos — solid team-fight fruit." },

  // ========== LEGENDARY ==========
  { id: "portal", name: "Portal", emoji: "🌀", rarity: "Legendary", type: "Natural", physicalValue: 10_000_000, permanentValue: 840_000_000, demand: 10, trend: "up", description: "Teleport gates — meta for travel, raids, and escaping battles." },
  { id: "buddha", name: "Buddha", emoji: "🧘", rarity: "Legendary", type: "Beast", physicalValue: 10_000_000, permanentValue: 685_000_000, demand: 10, trend: "up", description: "Transforms you into a tank — best grinding fruit thanks to melee range boost." },
  { id: "blizzard", name: "Blizzard", emoji: "🌨️", rarity: "Legendary", type: "Logia", physicalValue: 5_000_000, permanentValue: 430_000_000, demand: 5, trend: "stable", description: "Ice logia — wide AOE and freezing for crowd control." },
  { id: "phoenix", name: "Phoenix", emoji: "🔥", rarity: "Legendary", type: "Beast", physicalValue: 2_750_000, permanentValue: 195_000_000, demand: 3, trend: "stable", description: "Fire bird with self-revive — niche in PvP duels." },
  { id: "creation", name: "Creation", emoji: "🛠️", rarity: "Legendary", type: "Natural", physicalValue: 2_500_000, permanentValue: 130_000_000, demand: 2, trend: "down", description: "Toy soldier army — fun for PvE, low demand on the trading market." },
  { id: "sound", name: "Sound", emoji: "🎵", rarity: "Legendary", type: "Natural", physicalValue: 2_500_000, permanentValue: 165_000_000, demand: 4, trend: "stable", description: "Sound wave attacks — niche but flashy in PvP." },
  { id: "love", name: "Love", emoji: "❤️", rarity: "Legendary", type: "Natural", physicalValue: 1_200_000, permanentValue: 180_000_000, demand: 4, trend: "down", description: "Heart-based attacks — falling value after patches nerfed range." },

  // ========== RARE ==========
  { id: "lightning", name: "Lightning", emoji: "⚡", rarity: "Rare", type: "Logia", physicalValue: 35_000_000, permanentValue: 280_000_000, demand: 6, trend: "up", description: "Fast ranged logia — excellent beginner-friendly PvP fruit." },
  { id: "diamond", name: "Diamond", emoji: "💎", rarity: "Rare", type: "Natural", physicalValue: 800_000, permanentValue: 95_000_000, demand: 3, trend: "down", description: "Hard skin logia — niche tank fruit, low trader demand." },
  { id: "quake", name: "Quake", emoji: "🌍", rarity: "Rare", type: "Natural", physicalValue: 1_000_000, permanentValue: 85_000_000, demand: 2, trend: "down", description: "Earth-based ground pound — solid grinding in early seas." },
  { id: "magma", name: "Magma", emoji: "🌋", rarity: "Rare", type: "Logia", physicalValue: 1_200_000, permanentValue: 110_000_000, demand: 5, trend: "stable", description: "Lava logia — decent damage and immunity for PvE grinding." },
  { id: "spider", name: "Spider", emoji: "🕷️", rarity: "Rare", type: "Natural", physicalValue: 1_500_000, permanentValue: 95_000_000, demand: 2, trend: "stable", description: "Web attacks — low demand, mostly cosmetic use." },
  { id: "ghost", name: "Ghost", emoji: "👻", rarity: "Rare", type: "Natural", physicalValue: 850_000, permanentValue: 70_000_000, demand: 1, trend: "down", description: "Phase through attacks — underused after reworks." },
  { id: "rubber", name: "Rubber", emoji: "🩴", rarity: "Rare", type: "Natural", physicalValue: 780_000, permanentValue: 60_000_000, demand: 1, trend: "down", description: "Immune to electrical attacks — common newbie fruit." },
  { id: "eagle", name: "Eagle", emoji: "🦅", rarity: "Rare", type: "Beast", physicalValue: 600_000, permanentValue: 55_000_000, demand: 2, trend: "stable", description: "Bird-flight fruit — solid for getting around the map." },
  { id: "ice", name: "Ice", emoji: "🧊", rarity: "Rare", type: "Logia", physicalValue: 500_000, permanentValue: 45_000_000, demand: 3, trend: "stable", description: "Freezing logia — beginner-level PvP option." },
  { id: "sand", name: "Sand", emoji: "🏜️", rarity: "Rare", type: "Logia", physicalValue: 500_000, permanentValue: 42_000_000, demand: 2, trend: "stable", description: "Sand logia — low demand but functional for PvE." },
  { id: "dark", name: "Dark", emoji: "🌚", rarity: "Rare", type: "Logia", physicalValue: 500_000, permanentValue: 210_000_000, demand: 5, trend: "up", description: "Dark-elemental logia — recently buffed in Update 31." },

  // ========== UNCOMMON ==========
  { id: "flame", name: "Flame", emoji: "🔥", rarity: "Uncommon", type: "Logia", physicalValue: 280_000, permanentValue: 30_000_000, demand: 1, trend: "stable", description: "Basic fire logia — starter PvE fruit, low trader value." },
  { id: "spike", name: "Spike", emoji: "🌵", rarity: "Uncommon", type: "Natural", physicalValue: 180_000, permanentValue: 22_000_000, demand: 1, trend: "stable", description: "Spike-based attacks — small demand, used for early quests." },
  { id: "smoke", name: "Smoke", emoji: "💨", rarity: "Uncommon", type: "Logia", physicalValue: 100_000, permanentValue: 15_000_000, demand: 1, trend: "stable", description: "Smoke-screen logia — niche for mobility and stealth." },
  { id: "bomb", name: "Bomb", emoji: "💣", rarity: "Uncommon", type: "Natural", physicalValue: 80_000, permanentValue: 12_000_000, demand: 1, trend: "stable", description: "Bomb explosions — starter-level PvE choice." },
  { id: "spring", name: "Spring", emoji: "🌀", rarity: "Uncommon", type: "Natural", physicalValue: 60_000, permanentValue: 9_000_000, demand: 1, trend: "stable", description: "Bounce attacks — beginner fruit, little trading demand." },
  { id: "blade", name: "Blade", emoji: "🗡️", rarity: "Uncommon", type: "Natural", physicalValue: 30_000, permanentValue: 6_000_000, demand: 1, trend: "stable", description: "Slash combo fruit — underused but cheap to perm." },

  // ========== COMMON ==========
  { id: "spin", name: "Spin", emoji: "🌀", rarity: "Common", type: "Natural", physicalValue: 7_500, permanentValue: 2_500_000, demand: 1, trend: "stable", description: "Tornado fruit — bottom of the trade-value list." },
  { id: "rocket", name: "Rocket", emoji: "🚀", rarity: "Common", type: "Natural", physicalValue: 5_000, permanentValue: 2_000_000, demand: 1, trend: "stable", description: "Lowest-value fruit — mostly sold to NPCs or used for quests." },
];

// Gamepasses & limited items
export interface Gamepass {
  id: string;
  name: string;
  emoji: string;
  value: number;
  demand: number;
  trend: Trend;
  category: "gamepass" | "limited";
  description: string;
}

export const GAMEPASSES: Gamepass[] = [
  { id: "fruit-notifier", name: "Fruit Notifier", emoji: "🔔", value: 65_000_000, demand: 5, trend: "stable", category: "gamepass", description: "Spawn alert ping every 30 min — quality-of-life pick." },
  { id: "2x-mastery", name: "2x Mastery", emoji: "⚔️", value: 120_000_000, demand: 8, trend: "up", category: "gamepass", description: "Doubles mastery XP — best value gamepass for grinders." },
  { id: "2x-money", name: "2x Money", emoji: "💰", value: 110_000_000, demand: 6, trend: "stable", category: "gamepass", description: "Doubles Beli rewards from NPCs and quests." },
  { id: "2x-boss", name: "2x Boss Drops", emoji: "🎲", value: 90_000_000, demand: 7, trend: "stable", category: "gamepass", description: "Doubles boss drop rates — ideal for fruit-material hunting." },
  { id: "storage", name: "+1 Fruit Storage", emoji: "📦", value: 95_000_000, demand: 7, trend: "stable", category: "gamepass", description: "Adds one fruit slot — permanent QoL storage upgrade." },
  { id: "fast-boats", name: "Fast Boats", emoji: "⛵", value: 75_000_000, demand: 6, trend: "stable", category: "gamepass", description: "Higher ship speed across the seas." },
  { id: "dark-blade", name: "Dark Blade", emoji: "🗡️", value: 310_000_000, demand: 8, trend: "up", category: "gamepass", description: "Famous in-game sword — high demand, popular in PvP." },
  { id: "divine-portal", name: "Divine Portal", emoji: "🌌", value: 1_600_000_000, demand: 10, trend: "up", category: "limited", description: "Limited-time portal — extremely rare, top of the limited list." },
  { id: "werewolf", name: "Werewolf", emoji: "🐺", value: 520_000_000, demand: 8, trend: "stable", category: "limited", description: "Beast transformation — limited cosmetic accessory." },
  { id: "azura-bomb", name: "Azura Bomb", emoji: "💣", value: 310_000_000, demand: 7, trend: "stable", category: "limited", description: "Limited bomb cosmetic — flashy in PvP." },
  { id: "cyan-lightning", name: "Cyan Lightning", emoji: "⚡", value: 210_000_000, demand: 6, trend: "stable", category: "limited", description: "Lightning cosmetic — limited-time drops." },
];

// Helpers
export const formatValue = (value: number): string => {
  if (value >= 1_000_000_000) return `${(value / 1_000_000_000).toFixed(2)}B`;
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M`;
  if (value >= 1_000) return `${(value / 1_000).toFixed(1)}K`;
  return value.toLocaleString();
};

export const formatExact = (value: number): string => value.toLocaleString("en-US");
