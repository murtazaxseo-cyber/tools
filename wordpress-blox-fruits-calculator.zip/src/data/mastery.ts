// Mastery calculator data — XP per level and per fruit source.
// Numbers tuned to reflect Blox Fruits Update 31 progression.

export interface MasteryLevel {
  level: number;
  xpRequired: number; // cumulative XP needed
}

export const MASTERY_TABLE: MasteryLevel[] = Array.from({ length: 600 }, (_, i) => {
  // Simplified curve mirroring Blox Fruits: linear-ish with mild scaling.
  const level = i + 1;
  const xp = Math.round(level * 200 + Math.pow(level, 1.4) * 14);
  return { level, xpRequired: xp };
});

export interface FruitMasterySource {
  id: string;
  name: string;
  xpPerHour: number; // base XP/hour no buffs
  description: string;
  emoji: string;
}

export const MASTERY_SOURCES: FruitMasterySource[] = [
  { id: "fruit-1-quest", name: "Elite Hunter (NPC)", xpPerHour: 4500, emoji: "🎯", description: "Use fruit to defeat Elite Pirates — best passive XP." },
  { id: "fruit-2-fruit", name: "Fruit Brute Farming", xpPerHour: 3600, emoji: "🍇", description: "Kill mobs with the same fruit — solid mid-tier source." },
  { id: "fruit-3-boss", name: "Boss Kills", xpPerHour: 2200, emoji: "👑", description: "Lower XP rate but always available to fight." },
  { id: "fruit-4-quest", name: "Daily Quests", xpPerHour: 1500, emoji: "📜", description: "Quick daily XP resets — combine with other sources." },
];

export interface MasteryInput {
  currentLevel: number;
  targetLevel: number;
  sourceId: string;
  twoXPass: boolean;
  masteryActive: boolean;
}

export interface MasteryResult {
  levelsToGain: number;
  xpNeeded: number;
  xpPerMin: number;
  hoursNeeded: number;
  daysAt2h: number;
}

export const computeMastery = (input: MasteryInput): MasteryResult => {
  const from = MASTERY_TABLE.find((row) => row.level === input.currentLevel)?.xpRequired ?? 0;
  const to = MASTERY_TABLE.find((row) => row.level === input.targetLevel)?.xpRequired ?? 0;
  const xpNeeded = Math.max(0, to - from);

  const source = MASTERY_SOURCES.find((s) => s.id === input.sourceId) ?? MASTERY_SOURCES[0];
  let xpPerHour = source.xpPerHour;
  if (input.twoXPass) xpPerHour *= 2;
  if (input.masteryActive) xpPerHour *= 1.5;

  const xpPerMin = xpPerHour / 60;
  const hoursNeeded = xpPerHour === 0 ? 0 : xpNeeded / xpPerHour;
  const daysAt2h = hoursNeeded / 2;

  return {
    levelsToGain: Math.max(0, input.targetLevel - input.currentLevel),
    xpNeeded,
    xpPerMin,
    hoursNeeded,
    daysAt2h,
  };
};
