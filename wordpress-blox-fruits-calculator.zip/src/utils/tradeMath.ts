import { FRUITS, GAMEPASSES, type Fruit, type Gamepass } from "../data/fruits";

export type Side = "give" | "receive";
export type TradeMode = "physical" | "permanent";

export interface TradeItem {
  id: string;
  quantity: number;
}

export type CatalogItem =
  | (Fruit & { kind: "fruit" })
  | (Gamepass & { kind: "gamepass" });

const fruitItems: CatalogItem[] = FRUITS.map((f) => ({ ...f, kind: "fruit" as const }));
const gpItems: CatalogItem[] = GAMEPASSES.map((g) => ({ ...g, kind: "gamepass" as const }));

export const ALL_ITEMS: CatalogItem[] = [...fruitItems, ...gpItems];

export const getItem = (id: string): CatalogItem | undefined =>
  ALL_ITEMS.find((x) => x.id === id);

export const itemValue = (id: string, mode: TradeMode): number => {
  const item = getItem(id);
  if (!item) return 0;
  if (item.kind === "fruit") {
    return mode === "permanent" ? item.permanentValue : item.physicalValue;
  }
  return item.value;
};

export const itemDemand = (id: string): number => {
  const item = getItem(id);
  return item?.demand ?? 0;
};

export const itemName = (id: string): string => getItem(id)?.name ?? "Unknown";

export const itemEmoji = (id: string): string => getItem(id)?.emoji ?? "❓";

export const itemRarity = (id: string): string => {
  const item = getItem(id);
  if (!item) return "—";
  if (item.kind === "fruit") return item.rarity;
  return item.category === "limited" ? "Limited" : "Gamepass";
};

export const itemTrend = (id: string) => getItem(id)?.trend ?? "stable";

export const sideValue = (side: TradeItem[], mode: TradeMode): number =>
  side.reduce((sum, entry) => sum + itemValue(entry.id, mode) * entry.quantity, 0);

export const sideDemand = (side: TradeItem[]): number => {
  if (side.length === 0) return 0;
  const total = side.reduce((sum, entry) => sum + itemDemand(entry.id) * entry.quantity, 0);
  const qty = side.reduce((sum, entry) => sum + entry.quantity, 0) || 1;
  return total / qty;
};

export type Verdict = "win" | "fair" | "lose" | "empty";

export interface VerdictResult {
  verdict: Verdict;
  label: string;
  ratio: number;
  gap: number;
  giveValue: number;
  receiveValue: number;
}

const formatValueSafe = (v: number): string => {
  if (v >= 1_000_000_000) return `${(v / 1_000_000_000).toFixed(2)}B`;
  if (v >= 1_000_000) return `${(v / 1_000_000).toFixed(1)}M`;
  if (v >= 1_000) return `${(v / 1_000).toFixed(1)}K`;
  return v.toLocaleString();
};

export const calculateVerdict = (
  give: TradeItem[],
  receive: TradeItem[],
  mode: TradeMode
): VerdictResult => {
  const giveValue = sideValue(give, mode);
  const receiveValue = sideValue(receive, mode);

  if (giveValue === 0 && receiveValue === 0) {
    return { verdict: "empty", label: "Add items to compare", ratio: 0, gap: 0, giveValue, receiveValue };
  }

  const smaller = Math.min(giveValue, receiveValue);
  const bigger = Math.max(giveValue, receiveValue);
  const gap = bigger - smaller;
  const gapPercent = smaller === 0 ? 100 : (gap / smaller) * 100;

  let verdict: Verdict;
  let label: string;

  if (giveValue === 0) {
    verdict = "win";
    label = "FREE WIN — you receive value for nothing";
  } else if (receiveValue === 0) {
    verdict = "lose";
    label = "HARD LOSS — you give without receiving";
  } else if (gapPercent <= 7) {
    verdict = "fair";
    label = "FAIR TRADE — values are within 7%";
  } else if (receiveValue > giveValue) {
    verdict = "win";
    label = `You WIN — gaining ~${formatValueSafe(gap)} more value`;
  } else {
    verdict = "lose";
    label = `You LOSE — losing ~${formatValueSafe(gap)} more value`;
  }

  return {
    verdict,
    label,
    ratio: giveValue === 0 ? 0 : receiveValue / giveValue,
    gap,
    giveValue,
    receiveValue,
  };
};
